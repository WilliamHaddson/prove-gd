package br.com.prove.model.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RelatorioGd {

private LocalDate competencia;

private Long cdDiretoria;

private String nmDiretoria;

private Long cdRegional;

private String nmRegional;

private Long cdFilial;

private String nmFilial;

private Long cdEmpgcbConsultor;

private Long cdFunConsultor;

private String nmConsultor;

private Long cdEmpgcbCoordSenior;

private Long cdFunCoordSenior;

private String nmCoordSenior;

private Long cdEmpgcbCoordRegional;

private Long cdFunCoordRegional;

private String nmCoordRegional;

private Long cdEmpgcbGerente;

private Long cdFunGerente;

private String nmGerente;

private Long cdEmpgcbVendedor;

private Long cdFunVendedor;

private String nmVendedor;

private String vendedorCargo;

private String vendedorCategoria;

private String vendedorStatusGd;

private String vendedorJustificativaStatusGd;

private List<MapaMes> mediaHistorico = new ArrayList<>();

private BigDecimal atingimentoMonetario;

private BigDecimal mesVigenteMeta;

private BigDecimal mesVigenteRealizado;

private Double mesVigenteMedia;

private BigDecimal acumuladoMesVigenteMeta;

private BigDecimal acumuladoMesVigenteRealizado;

private Double acumuladoMesVigenteMedia;

private BigDecimal crescimentoMonetario;

private String statusCriterioProve;

private String criterioProveJustificativa;

private String statusGd;

private String statusGdJustificativa;

private Integer criterioProve;

private Integer valorMinimoMedia;

private Integer valorMaximoMedia;

private Integer valorMinimoMeta;

private Integer qtdMesesMapeamento;
}