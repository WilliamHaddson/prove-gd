package br.com.prove.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.prove.model.dto.RelatorioGd;
import br.com.prove.service.RelatorioGdService;
import br.com.prove.service.ReportService;

@RestController
@RequestMapping("/relatorios")
public class RelatorioGdController {
	
	private @Autowired RelatorioGdService service;
	
	private @Autowired ReportService reportService;
	
	@GetMapping
	public ModelAndView novo() {
		ModelAndView mv = new ModelAndView("Relatorios");
		
		return mv;
	}
	
	@GetMapping(path = "/gerar", produces = "application/xls")
	public ResponseEntity<byte[]> gerarExcelVendas() {
		List<RelatorioGd> relatorios = service.listar();
		
		byte[] pdfToExcel = reportService.emitirRelatorio(relatorios);
		String filename = UUID.randomUUID().toString() + "__relatorio-gd.xls";
		
		var headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename);
		
		return ResponseEntity.ok()
				.contentType(MediaType.parseMediaType("application/xls"))
				.headers(headers)
				.body(pdfToExcel);
	}

}
