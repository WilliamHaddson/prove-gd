package br.com.prove.assembler;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.prove.model.Relatorio;
import br.com.prove.model.dto.RelatorioGd;

@Component
public class RelatorioGdAssembler {
	
	@Autowired
	private ModelMapper modelMapper;
	
	public RelatorioGd toModel(Relatorio relatorio) {
	    
		return modelMapper.map(relatorio, RelatorioGd.class);
	}
	
	public List<RelatorioGd> toCollectionModel(List<Relatorio> relatorios) {
		return relatorios.stream()
				.map(relatorio -> toModel(relatorio))
				.collect(Collectors.toList());
	}

}
