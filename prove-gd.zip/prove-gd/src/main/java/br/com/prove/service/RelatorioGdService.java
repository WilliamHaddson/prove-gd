package br.com.prove.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.prove.assembler.MapaMesAssembler;
import br.com.prove.assembler.RelatorioGdAssembler;
import br.com.prove.model.Relatorio;
import br.com.prove.model.dto.MapaMes;
import br.com.prove.model.dto.RelatorioGd;
import br.com.prove.repository.MapaRepository;
import br.com.prove.repository.RelatorioRepository;

@Service
public class RelatorioGdService {
	
	private @Autowired RelatorioRepository repository;
	
	private @Autowired MapaRepository mmRepository;
	
	private @Autowired RelatorioGdAssembler assembler;
	
	private @Autowired MapaMesAssembler mmAssembler;
	
	public List<RelatorioGd> listar() {
		List<Relatorio> relatorios = repository.findAll();
		List<MapaMes> mapas = mmAssembler.toCollectionModel(mmRepository.findAll());
		List<RelatorioGd> relatoriosGd = new ArrayList<>();
		
		relatorios.forEach(relatorio -> {
			RelatorioGd rgd = new RelatorioGd();
			rgd = assembler.toModel(relatorio);
			rgd.setMediaHistorico(mapas);
			relatoriosGd.add(rgd);
		});
		
		return relatoriosGd;
	}

}
