package br.com.prove.infrastructure.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.springframework.stereotype.Service;

import br.com.prove.exception.ReportException;
import br.com.prove.model.dto.RelatorioGd;
import br.com.prove.service.ReportService;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

@Service
public class ExcelReportService implements ReportService {

	@Override
	public byte[] emitirRelatorio(List<RelatorioGd> toEmit) {
		try {
	
			JRXlsxExporter exporter = new JRXlsxExporter();
			File destFile = new File("arquivo_temporario.xlsx");
			String path = "/relatorios/Relatorio-Gd.jasper";
			
			var inputStream = this.getClass().getResourceAsStream(path);
		
			var parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));
		
			var dataSource = new JRBeanCollectionDataSource(toEmit);
		
			var jasperPrint = JasperFillManager.fillReport(inputStream, parametros, dataSource);
		
			exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
			exporter.setExporterOutput(
			 new SimpleOutputStreamExporterOutput(destFile));
		
			SimpleXlsxReportConfiguration reportConfig
			 = new SimpleXlsxReportConfiguration();
			reportConfig.setSheetNames(new String[] { "GD" });
		
			exporter.setConfiguration(reportConfig);
			exporter.exportReport();
		
			return readFileToByteArray(destFile);
	
		} catch (Exception e) {
			throw new ReportException("Não foi possível emitir relatório do GD", e);
		}
	}

	private static byte[] readFileToByteArray(File file){
		FileInputStream fis = null;

		byte[] bArray = new byte[(int) file.length()];
		try{
			fis = new FileInputStream(file);
			fis.read(bArray);
			fis.close();                  
		}catch(IOException ioExp){
			ioExp.printStackTrace();
		}
		return bArray;
	}

}
