package br.com.prove.service;

import java.util.List;

import br.com.prove.model.dto.RelatorioGd;

public interface ReportService {
	
	byte[] emitirRelatorio(List<RelatorioGd> toEmit);

}
