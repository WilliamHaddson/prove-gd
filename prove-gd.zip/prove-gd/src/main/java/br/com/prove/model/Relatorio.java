package br.com.prove.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
public class Relatorio{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private Long id;

	private LocalDate competencia;

	private Long cdDiretoria;

	private String nmDiretoria;

	private Long cdRegional;

	private String nmRegional;

	private Long cdFilial;

	private String nmFilial;

	private Long cdEmpgcbConsultor;

	private Long cdFunConsultor;

	private String nmConsultor;

	private Long cdEmpgcbCoordSenior;

	private Long cdFunCoordSenior;

	private String nmCoordSenior;

	private Long cdEmpgcbCoordRegional;

	private Long cdFunCoordRegional;

	private String nmCoordRegional;

	private Long cdEmpgcbGerente;

	private Long cdFunGerente;

	private String nmGerente;

	private Long cdEmpgcbVendedor;

	private Long cdFunVendedor;

	private String nmVendedor;

	private String vendedorCargo;

	private String vendedorCategoria;

	private String vendedorStatusGd;

	private String vendedorJustificativaStatusGd;

	private BigDecimal atingimentoMonetario;

	private BigDecimal mesVigenteMeta;

	private BigDecimal mesVigenteRealizado;

	private Double mesVigenteMedia;

	private BigDecimal acumuladoMesVigenteMeta;

	private BigDecimal acumuladoMesVigenteRealizado;

	private Double acumuladoMesVigenteMedia;

	private BigDecimal crescimentoMonetario;

	private String statusCriterioProve;

	private String criterioProveJustificativa;

	private String statusGd;

	private String statusGdJustificativa;

	private Integer criterioProve;

	private Integer valorMinimoMedia;

	private Integer valorMaximoMedia;

	private Integer valorMinimoMeta;

	private Integer qtdMesesMapeamento;
}
