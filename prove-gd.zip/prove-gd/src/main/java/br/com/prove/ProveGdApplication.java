package br.com.prove;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProveGdApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProveGdApplication.class, args);
	}

}
