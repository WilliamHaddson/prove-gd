package br.com.prove.assembler;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.prove.model.Mapa;
import br.com.prove.model.dto.MapaMes;

@Component
public class MapaMesAssembler {
	
	@Autowired
	private ModelMapper modelMapper;
	
	public MapaMes toModel(Mapa mapa) {
	    
		return modelMapper.map(mapa, MapaMes.class);
	}
	
	public List<MapaMes> toCollectionModel(List<Mapa> mapas) {
		return mapas.stream()
				.map(mapa -> toModel(mapa))
				.collect(Collectors.toList());
	}

}
