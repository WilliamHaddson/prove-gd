package br.com.prove.modelmapper;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import br.com.prove.model.Relatorio;
import br.com.prove.model.dto.RelatorioGd;

@Configuration
public class ModelMapperConfig {

	@Bean
	public ModelMapper modelMapper() {
		var modelMapper = new ModelMapper();
		
		modelMapper.createTypeMap(Relatorio.class, RelatorioGd.class)
			.addMappings(mapper -> mapper.skip(RelatorioGd::setMediaHistorico));
		
		return modelMapper;
	}
	
}
